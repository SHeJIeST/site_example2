$(window).resize(function(e){
    if($(window).width() < 1200) {
    console.log($(window).width());
     $("#bg4").each(function() {
       $(this).attr("src", "assets/img/Vector53.png");
                 });
     $("#bg2").each(function() {
        $(this).attr("src", "assets/img/MaskGroup.png");
                });
             } else if ($(window).width() >= 1200) {
                 $("#bg4").each(function() {
                 $(this).attr("src","assets/img/bg4.png");
                 });
                 $("#bg2").each(function() {
                 $(this).attr("src","assets/img/bg2.png");
                 });                         
     }
     if($(window).width() < 768) {
        console.log($(window).width());
        if($("figure").is(".block6")) {
            
        }else{
            $('<figure class="block6">' +
            '<img src="assets/img/points.png" alt="block6">' +
            '</figure>').appendTo("#what1");
        }
     }   
 });